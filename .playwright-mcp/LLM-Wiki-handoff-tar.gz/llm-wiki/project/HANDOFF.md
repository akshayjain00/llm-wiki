# LLM Wiki — Handoff to Claude Code (Phase 3.1)

The UI prototype now wires every previously-dead button to a realistic interaction
(toast confirmation, progress modal, or multi-step form). Behind each interaction
is a contract Claude Code must implement on the server side. Below is the exact
delta from "the UI does the right thing locally" to "the UI talks to the real
backend".

The UI runs at `http://localhost:5174`. The server is started with
`llm-wiki serve --workspace ~/AI_V2/team_memory_wiki`. Everything below assumes
that server (a) hosts the static UI and (b) exposes the JSON endpoints described
in §1.

---

## 1. HTTP endpoints to add

All endpoints are JSON, bound to `127.0.0.1:5174` only. None mutates a markdown
file outside the **New Project** flow (§1.5).

### 1.1 `POST /api/graph/rebuild`
**Triggered by:** Overview → *rebuild*, Health → *rebuild graph*, command palette → *rebuild*.

```jsonc
// Request
{ "force": false }                      // force=true ignores hash cache

// Streaming response: text/event-stream of progress events
data: {"step":"scan","label":"Scanning durable pages","detail":"142 files"}
data: {"step":"parse","label":"Parsing frontmatter & headings"}
data: {"step":"alias","label":"Resolving entity aliases","detail":"264 candidates"}
data: {"step":"edges","label":"Materialising edges"}
data: {"step":"propose","label":"Generating link proposals"}
data: {"step":"commit","label":"Writing state/index.db"}
data: {"step":"done","run_id":"graph_a91c","pages":142,"edges":318,"proposals":17,
       "duration_ms":24300,"markdown_writes":0}
```

The UI's `RebuildModal` already mirrors these step names. Map the SSE events 1:1
and the existing modal will animate correctly. **Critical invariant**: response
must include `markdown_writes: 0` for the success banner to be honest.

### 1.2 `POST /api/health/recheck`
**Triggered by:** Health → *re-check*.

```jsonc
{}                                       // no body
// → 200
{ "ran_at": "2026-05-09T14:11:00Z",
  "checks": [
    { "id":"graph_tables","status":"ok","value":"4/4" },
    { "id":"rebuild_fresh","status":"ok","value":"0 stale" },
    { "id":"unresolved_links","status":"warn","value":"3" },
    { "id":"duplicate_alias","status":"ok","value":"0" },
    { "id":"proposal_drift","status":"ok","value":"0.04" },
    { "id":"mcp_handshake","status":"ok","value":"v1.3" }
  ]
}
```

The `RecheckModal` will swap to the success state when the response lands.

### 1.3 `GET /api/proposals/export?format=csv`
**Triggered by:** Proposed Links → *export queue*.

The UI currently exports a CSV client-side from in-memory data. Replace that
fetch path with this endpoint when wiring up the real client. Schema must match
the table headers shown in the queue:

```
id,source_path,line,original_text,target_node_id,target_title,confidence,rationale
```

`format=jsonl` should also be supported for piping into the MCP layer.

### 1.4 `GET /api/mcp/uri/:nodeId`
**Triggered by:** *copy MCP URI* on Page detail and Entity detail.

Returns the canonical MCP URI for a node so the UI doesn't have to construct it
client-side (the prototype currently does `wiki://{id}`, which is the right
shape but should be authoritative server-side):

```jsonc
{ "uri": "wiki://project:hcv",
  "kind": "project",
  "tools": ["wiki.read_page","wiki.list_backlinks","wiki.list_proposals"] }
```

### 1.5 `POST /api/projects` — **New Project flow** (the only write path)
**Triggered by:** top bar *new project* and Overview *new project*.

The 3-step modal collects:

```jsonc
{
  "name":        "Linear Importer",       // required
  "slug":        "linear-importer",       // required, validated against /^[a-z0-9-]{1,48}$/
  "owner":       "Akshay Jain",
  "description": "…",
  "template":    "standard",              // standard | eng | research | minimal
  "seed_from":   "~/repos/linear-importer" // optional
}
```

On `POST` the server must do the following, atomically and in this order:

1. **Validate slug uniqueness** against `graph_nodes` and the projects directory.
   On collision, return `409 { "error":"slug_exists","existing":"project:linear-importer" }`.
2. **Scaffold pages** at `~/AI_V2/team_memory_wiki/projects/<slug>/<page>.md`,
   one file per template (page list below). Each file gets frontmatter:
   ```yaml
   title: <Project Name> — <page>
   project: <slug>
   kind: <page>
   owner: <owner>
   created: <ISO-8601>
   ```
3. **Register the canonical entity** `project:<slug>` in `graph_nodes` with
   `aliases: [<name>, <slug>]` and `owner` metadata.
4. **Optional seed scan**: if `seed_from` is set, walk that directory (read-only),
   summarise notable READMEs/specs, and write the summaries into the project's
   `overview.md` *before* it lands on disk. Never mutate `seed_from`.
5. **Queue a graph rebuild** (same path as §1.1) so backlinks/proposals refresh.
6. **Return** the freshly-registered node so the UI can navigate to it:

   ```jsonc
   { "node_id": "project:linear-importer",
     "path":    "projects/linear-importer/",
     "pages":   ["overview","decisions","runbook","open-questions"],
     "rebuild_run_id": "graph_b13f" }
   ```

**Template → pages mapping** (already encoded in `actions.jsx :: templatePages`):

| template   | pages |
|-----------|-------|
| `standard` | overview, decisions, runbook, open-questions |
| `eng`      | overview, architecture, adr, runbook, changelog |
| `research` | overview, prior-art, experiments, findings |
| `minimal`  | overview |

**Auth / safety**: project creation is the only write path. Gate it on a
`--allow-writes` flag at server start (default off in `llm-wiki serve`). When
the flag is off, return `403 { "error":"writes_disabled" }`.

---

## 2. Client wiring tasks

In the running app the buttons currently demonstrate *what should happen* —
swap the mock call sites for real fetches. Locations:

| File | Function / button | Replace |
|------|------|---------|
| `views.jsx` | `OverviewView` rebuild button | `actions.openRebuild()` → `fetch('/api/graph/rebuild', { method:'POST' })` and stream events |
| `views.jsx` | `HealthView` re-check button | `actions.openRecheck()` → POST `/api/health/recheck` |
| `views.jsx` | `HealthView` rebuild graph | wire to same SSE handler |
| `views.jsx` | `ProposalsView` export queue | swap client-side CSV for `GET /api/proposals/export?format=csv` |
| `views.jsx` | Page/Entity *copy MCP URI* | `GET /api/mcp/uri/:id`, write to clipboard |
| `actions.jsx` | `NewProjectModal.handleCreate` | `POST /api/projects`, then `navigate('entities', { id: node_id })` |
| `app.jsx` | `TopBar.onNewProject` | already opens the modal — no change |

Each call site already has a `useToast()` handle; surface `409`/`403`/`500` as
`kind:'err'` toasts with the server's `error` string verbatim.

---

## 3. Persistence and read-only invariants

- The UI never mutates markdown except via §1.5. Adding any other write path
  requires a new section in this doc.
- `state/index.db` is the source of truth for every list view. The UI does not
  re-scan markdown at query time.
- The MCP server must continue to expose **only read tools** (`wiki.read_page`,
  `wiki.list_backlinks`, `wiki.list_proposals`, `wiki.search`). Project creation
  is HTTP-only, not exposed over MCP, to keep the agent surface read-only.

---

## 4. UX behaviours already in place (no work needed)

- Rebuild progress modal animates 6 steps and shows `markdown_writes: 0`.
- New-project modal validates slug live, shows the *will create* preview, and
  toasts on completion.
- Re-check modal shows a spinner and lands on the warning summary.
- Export-queue produces a CSV client-side as a fallback if the endpoint 404s.
- *Copy MCP URI* falls back to `wiki://<id>` if `/api/mcp/uri/:id` is missing.

These fallbacks should stay — they make the UI usable when the server is
running an older build during a deploy.

---

## 5. Acceptance checklist

- [ ] `POST /api/graph/rebuild` streams 6 step events and a `done` summary.
- [ ] `POST /api/health/recheck` returns the 6-check payload.
- [ ] `GET /api/proposals/export?format=csv` produces the same column set the
      modal currently generates client-side.
- [ ] `GET /api/mcp/uri/:nodeId` returns canonical URIs for at least
      `project:*`, `person:*`, `concept:*`, and `page:*`.
- [ ] `POST /api/projects` scaffolds files, registers the entity, queues a
      rebuild, and returns the node id — gated on `--allow-writes`.
- [ ] After a successful project create, the UI navigates to the new entity
      page and the right context panel shows the freshly-scaffolded pages.
- [ ] No code path outside §1.5 writes to markdown. Verified by running with
      filesystem write-watch and exercising every button.
