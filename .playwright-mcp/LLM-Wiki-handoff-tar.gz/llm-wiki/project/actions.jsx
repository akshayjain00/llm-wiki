/* global React, Icon */
// Action wiring layer. The prototype has no real backend, so each user-facing
// "do something" button surfaces (a) a toast confirmation describing what would
// happen against the live server, and (b) the exact API contract Claude Code
// must implement. Centralising this makes the handoff doc easier to keep in
// sync with the UI behaviour.
const { useState, useEffect, useRef, createContext, useContext, useCallback } = React;

// ─── Toasts ────────────────────────────────────────────────────────────────
const ToastCtx = createContext(null);
function ToastProvider({ children }) {
  const [items, setItems] = useState([]);
  const idRef = useRef(0);
  const push = useCallback((msg, opts = {}) => {
    const id = ++idRef.current;
    const it = { id, msg, kind: opts.kind || 'info', detail: opts.detail, ttl: opts.ttl ?? 4500 };
    setItems(xs => [...xs, it]);
    if (it.ttl) setTimeout(() => setItems(xs => xs.filter(x => x.id !== id)), it.ttl);
    return id;
  }, []);
  const dismiss = useCallback(id => setItems(xs => xs.filter(x => x.id !== id)), []);
  return (
    <ToastCtx.Provider value={{ push, dismiss }}>
      {children}
      <div className="toast-stack" role="status" aria-live="polite">
        {items.map(it => (
          <div key={it.id} className={'toast t-' + it.kind}>
            <div className="toast__icon">
              {it.kind === 'ok' ? <Icon name="check" /> :
               it.kind === 'warn' ? <Icon name="bolt" /> :
               it.kind === 'err' ? <Icon name="x" /> : <Icon name="info" />}
            </div>
            <div className="toast__body">
              <div className="toast__msg">{it.msg}</div>
              {it.detail && <div className="toast__detail">{it.detail}</div>}
            </div>
            <button className="toast__x" onClick={() => dismiss(it.id)} aria-label="Dismiss">×</button>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
function useToast() { return useContext(ToastCtx); }

// ─── Modal shell ───────────────────────────────────────────────────────────
function Modal({ open, onClose, title, sub, children, footer, width = 560 }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = e => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-scrim" onClick={onClose} role="dialog" aria-modal="true" aria-label={title}>
      <div className="modal" style={{ width }} onClick={e => e.stopPropagation()}>
        <div className="modal__h">
          <div>
            <h2>{title}</h2>
            {sub && <p>{sub}</p>}
          </div>
          <button className="modal__x" onClick={onClose} aria-label="Close">×</button>
        </div>
        <div className="modal__b">{children}</div>
        {footer && <div className="modal__f">{footer}</div>}
      </div>
    </div>
  );
}

// ─── Rebuild graph progress modal ──────────────────────────────────────────
const REBUILD_STEPS = [
  { label: 'Scanning durable pages',           detail: 'walking ~/AI_V2/team_memory_wiki/pages/**/*.md' },
  { label: 'Parsing frontmatter & headings',   detail: 'pyyaml · markdown-it · 142 files' },
  { label: 'Resolving entity aliases',         detail: 'entity_aliases · 264 candidates' },
  { label: 'Materialising edges',              detail: 'links_to · mentions · belongs_to_project' },
  { label: 'Generating link proposals',        detail: 'rule-based + cosine threshold 0.88' },
  { label: 'Writing state/index.db',           detail: 'transaction commit · 0 markdown writes' },
];
function RebuildModal({ open, onClose, onDone }) {
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (!open) { setStep(0); setDone(false); return undefined; }
    setStep(0); setDone(false);
    let i = 0;
    const tick = () => {
      i += 1;
      if (i >= REBUILD_STEPS.length) {
        setStep(REBUILD_STEPS.length);
        setDone(true);
        onDone && onDone();
      } else {
        setStep(i);
        setTimeout(tick, 450 + Math.random() * 300);
      }
    };
    const t = setTimeout(tick, 350);
    return () => clearTimeout(t);
  }, [open]);
  return (
    <Modal open={open} onClose={onClose} title="Rebuild graph"
           sub="Re-derives state/index.db from current markdown. Read-only against the wiki — no markdown is mutated."
           footer={
             <>
               <span className="mono dim">run graph_a91c · workspace ~/AI_V2/team_memory_wiki</span>
               <button className={'btn ' + (done ? 'primary' : 'ghost')} onClick={onClose} disabled={!done}>
                 {done ? 'Close' : 'Working…'}
               </button>
             </>
           }>
        <ol className="rebuild-steps">
          {REBUILD_STEPS.map((s, i) => {
            const state = i < step ? 'ok' : i === step && !done ? 'run' : i === step && done ? 'ok' : 'idle';
            return (
              <li key={i} className={'r-step is-' + state}>
                <span className="r-icn">
                  {state === 'ok' ? <Icon name="check" /> :
                   state === 'run' ? <span className="spin" /> :
                   <span className="dot" />}
                </span>
                <span className="r-lbl">{s.label}</span>
                <span className="r-detail mono">{s.detail}</span>
              </li>
            );
          })}
        </ol>
        {done && (
          <div className="rebuild-done">
            <Icon name="check" /> Rebuild complete · 142 pages · 318 edges · 17 proposals · 24.3s · 0 markdown writes
          </div>
        )}
    </Modal>
  );
}

// ─── New Project modal ─────────────────────────────────────────────────────
const PROJECT_TEMPLATES = [
  { id: 'standard',   name: 'Standard project',    desc: 'overview · decisions · runbook · open-questions' },
  { id: 'eng',        name: 'Engineering project', desc: 'overview · architecture · adr · runbook · changelog' },
  { id: 'research',   name: 'Research note',       desc: 'overview · prior-art · experiments · findings' },
  { id: 'minimal',    name: 'Minimal',             desc: 'overview only' },
];
const OWNERS = ['Akshay Jain', 'Data Team', 'Eng / Knowledge', 'ML Platform', 'Internal Tools'];

function NewProjectModal({ open, onClose }) {
  const toast = useToast();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    name: '', slug: '', owner: 'Akshay Jain',
    template: 'standard', description: '',
    seedFromPath: '',
  });
  useEffect(() => {
    if (open) { setStep(0); setForm(f => ({ ...f, name: '', slug: '', description: '', seedFromPath: '' })); }
  }, [open]);

  const update = (k, v) => setForm(f => {
    const next = { ...f, [k]: v };
    if (k === 'name') next.slug = slugify(v);
    return next;
  });

  const tpl = PROJECT_TEMPLATES.find(p => p.id === form.template);
  const pages = templatePages(form.template);
  const canNext = step === 0 ? form.name.trim().length > 0 : true;

  const handleCreate = () => {
    setStep(3);
    setTimeout(() => {
      onClose();
      toast.push(`Project created · ${form.name}`, {
        kind: 'ok',
        detail: `~/AI_V2/team_memory_wiki/projects/${form.slug}/ · ${pages.length} pages · graph rebuild queued`,
      });
    }, 1500);
  };

  return (
    <Modal open={open} onClose={onClose} title="New project"
           sub={`Scaffolds a project folder under ~/AI_V2/team_memory_wiki/projects/ and triggers the standard project flow: page templates, entity registration, and a graph rebuild.`}
           width={640}
           footer={
             <>
               <span className="mono dim">step {Math.min(step + 1, 3)} of 3</span>
               <span style={{ display: 'flex', gap: 8 }}>
                 <button className="btn ghost" onClick={onClose}>Cancel</button>
                 {step > 0 && step < 3 && <button className="btn ghost" onClick={() => setStep(s => s - 1)}>Back</button>}
                 {step < 2 && <button className="btn primary" disabled={!canNext} onClick={() => setStep(s => s + 1)}>Continue</button>}
                 {step === 2 && <button className="btn primary" onClick={handleCreate}>Create project</button>}
               </span>
             </>
           }>
      {step === 0 && (
        <div className="form">
          <div className="field">
            <label>Project name</label>
            <input autoFocus value={form.name} onChange={e => update('name', e.target.value)}
                   placeholder="e.g. Linear Importer" />
          </div>
          <div className="field">
            <label>Slug <span className="mono dim">— folder + entity id</span></label>
            <input value={form.slug} onChange={e => update('slug', slugify(e.target.value))} placeholder="linear-importer" />
            <div className="hint">Becomes <span className="mono">~/AI_V2/team_memory_wiki/projects/{form.slug || '…'}/</span> and <span className="mono">project:{form.slug || '…'}</span>.</div>
          </div>
          <div className="field">
            <label>Owner</label>
            <div className="chip-group">
              {OWNERS.map(o => (
                <button key={o} type="button"
                        className={'chip-btn' + (form.owner === o ? ' is-on' : '')}
                        onClick={() => update('owner', o)}>{o}</button>
              ))}
            </div>
          </div>
          <div className="field">
            <label>One-line description <span className="mono dim">— optional</span></label>
            <input value={form.description} onChange={e => update('description', e.target.value)}
                   placeholder="What is this project for?" />
          </div>
        </div>
      )}
      {step === 1 && (
        <div className="form">
          <div className="field">
            <label>Template</label>
            <div className="tpl-list">
              {PROJECT_TEMPLATES.map(p => (
                <button key={p.id} type="button"
                        className={'tpl-row' + (form.template === p.id ? ' is-on' : '')}
                        onClick={() => update('template', p.id)}>
                  <span className="tpl-row__radio" />
                  <span>
                    <div className="tpl-row__name">{p.name}</div>
                    <div className="tpl-row__desc mono">{p.desc}</div>
                  </span>
                </button>
              ))}
            </div>
          </div>
          <div className="field">
            <label>Seed from existing folder <span className="mono dim">— optional</span></label>
            <input value={form.seedFromPath} onChange={e => update('seedFromPath', e.target.value)}
                   placeholder="~/repos/linear-importer" />
            <div className="hint">If set, the LLM will scan this path on first rebuild and pre-populate the project's overview, entities, and decisions pages.</div>
          </div>
        </div>
      )}
      {step === 2 && (
        <div className="form">
          <div className="confirm">
            <h3>Will create</h3>
            <ul className="path-list">
              <li><span className="mono">projects/{form.slug}/</span> <span className="dim">— project folder</span></li>
              {pages.map(p => <li key={p}><span className="mono">projects/{form.slug}/{p}.md</span> <span className="dim">— from <span className="mono">{form.template}</span> template</span></li>)}
            </ul>
            <h3 style={{ marginTop: 16 }}>And register</h3>
            <ul className="path-list">
              <li><span className="mono">project:{form.slug}</span> <span className="dim">— canonical entity, owner: {form.owner}</span></li>
              <li><span className="mono">graph rebuild</span> <span className="dim">— queued; ~25s; 0 markdown writes outside this project</span></li>
              {form.seedFromPath && <li><span className="mono">seed scan</span> <span className="dim">— {form.seedFromPath} → page proposals</span></li>}
            </ul>
            <div className="callout">
              <Icon name="bolt" />
              <span>This is the only flow in the UI that <b>writes</b> to the workspace. Page edits and link approvals still happen out-of-band.</span>
            </div>
          </div>
        </div>
      )}
      {step === 3 && (
        <div className="form" style={{ alignItems: 'center', textAlign: 'center', padding: '32px 0' }}>
          <div className="spin" style={{ width: 28, height: 28, borderWidth: 3 }} />
          <div style={{ marginTop: 16, color: 'var(--ink-1)' }}>Creating <b>{form.name}</b>…</div>
          <div className="mono dim" style={{ marginTop: 4, fontSize: 11 }}>scaffolding {pages.length} pages · registering entity · queueing rebuild</div>
        </div>
      )}
    </Modal>
  );
}

function slugify(s) {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 48);
}
function templatePages(id) {
  switch (id) {
    case 'eng':      return ['overview', 'architecture', 'adr', 'runbook', 'changelog'];
    case 'research': return ['overview', 'prior-art', 'experiments', 'findings'];
    case 'minimal':  return ['overview'];
    default:         return ['overview', 'decisions', 'runbook', 'open-questions'];
  }
}

// ─── Re-check progress (health) ────────────────────────────────────────────
function RecheckModal({ open, onClose }) {
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (!open) { setDone(false); return undefined; }
    const t = setTimeout(() => setDone(true), 1100);
    return () => clearTimeout(t);
  }, [open]);
  return (
    <Modal open={open} onClose={onClose} title="Re-check workspace health"
           sub="Runs the 6 diagnostic checks against state/index.db and the live filesystem."
           footer={<button className="btn primary" onClick={onClose} disabled={!done}>{done ? 'Close' : 'Checking…'}</button>}>
      <div style={{ padding: '12px 0' }}>
        {!done ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span className="spin" />
            <span className="mono dim">running 6 checks · verifying graph schema · alias hygiene · proposal drift…</span>
          </div>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, color: 'var(--ok)' }}>
            <Icon name="check" />
            <span>All 6 checks passed. 1 warning unchanged: <span className="mono">unresolved_links · 3</span>.</span>
          </div>
        )}
      </div>
    </Modal>
  );
}

Object.assign(window, { ToastProvider, useToast, Modal, RebuildModal, NewProjectModal, RecheckModal });
